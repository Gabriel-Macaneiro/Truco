#ifndef JOGADOR_H_INCLUDED
#define JOGADOR_H_INCLUDED

#include <vector>
#include "carta.h"

namespace final{

// definição da classe Jogador
class Jogador{
    // classe Mao é definida como amiga para que ela possa distribuir cartas
    // para os jogadores e adicionar pontos a eles
    friend class Mao;
public:
    Jogador();  // construtor padrão da classe Jogador

    int getPontos();  // método para retornar os pontos do jogador

    std::vector<Carta> getBaralhoDoJogador();  // método para retornar o baralho do jogador

protected:
    //Atributos
    std::vector<Carta> baralhoDoJogador;  // vetor de cartas que representa o baralho do jogador

    int _pontos;  // número de pontos do jogador

    //M�todos
    void receberCarta(Carta);  // adiciona uma carta passada como parâmetro no baralho do jogador

    void redefinirCartas();  // remove todas as cartas do baralho do jogador

    void adicionarPontos(int);  // aumenta o número de pontos do jogador
};

}

#endif // JOGADOR_H_INCLUDED
