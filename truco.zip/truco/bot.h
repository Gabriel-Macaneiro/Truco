#ifndef BOT_H_INCLUDED
#define BOT_H_INCLUDED

#include <string>
#include "jogador.h"

namespace final{

// definição da classe Bot
class Bot : public Jogador{
public:
    Bot();  // construtor padrão da classe Bot

    std::string getNome();  // retorna o nome do bot

    // joga uma carta já sabendo a carta que a pessoa jogou
    Carta jogarCarta(Carta cartaPessoa);

    Carta jogarCarta();  // joga uma carta aleatoriamente

    bool aceitarTruco();  // determina se o bot aceitará o truco ou não

    bool pedirTruco();  // determina se o bot irá pedir truco ou não
private:
    std::string _nome;  // nome do bot
};

}

#endif // BOT_H_INCLUDED
