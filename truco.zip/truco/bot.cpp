#include <random>
#include <chrono>
#include <vector>
#include "bot.h"

namespace final{

// construtor inicializa o nome do bot
Bot::Bot(){
    this->_nome = "Bot";
}

// retorna o nome do bot
std::string Bot::getNome(){
    return _nome;
}

// joga uma carta já sabendo a carta que a pessoa jogou
Carta Bot::jogarCarta(Carta cartaPessoa){
    Carta carta;
    // verifica se o bot tem alguma carta que tenha maior ou igual valor que a carta da pessoa
    // se ele tiver, ele irá jogá-la
    for(unsigned int i = 0; i < baralhoDoJogador.size(); i++){
        if(baralhoDoJogador[i].getValor() >= cartaPessoa.getValor()){
            carta = baralhoDoJogador[i];  // salva qual a carta a ser retirada

            // adiciona a última carta na posição da carta a ser retirada
            baralhoDoJogador[i] = baralhoDoJogador[baralhoDoJogador.size()-1];

            baralhoDoJogador.pop_back();  // retira a última carta
            return carta;
        }
    }

    // caso o bot não tenha nenhuma carta de maior valor que a carta da pessoa
    // joga uma carta aleatoriamente
    return this->jogarCarta();
}

// joga uma carta aleatoriamente
Carta Bot::jogarCarta(){
    // gera uma posição aleatória para retirar uma carta do baralho do bot
    std::mt19937 gen(static_cast<long unsigned int>(time(0)));
    std::uniform_int_distribution<long unsigned int> dis(0, baralhoDoJogador.size()-1);
    long unsigned int posicao = dis(gen);

    Carta carta;
    carta = baralhoDoJogador[posicao];  // salva qual a carta a ser retirada

    // adiciona a última carta na posição da carta a ser retirada
    baralhoDoJogador[posicao] = baralhoDoJogador[baralhoDoJogador.size()-1];

    baralhoDoJogador.pop_back();  // retira a última carta
    return carta;
}

// determina se o bot irá aceitar o truco ou não
bool Bot::aceitarTruco(){
    int soma = 0;
    // soma os valores das cartas do bot
    for (unsigned int i = 0; i < baralhoDoJogador.size(); i++)
        soma += baralhoDoJogador[i].getValor();

    // se o bot estiver com uma mão razoavelmente boa ele aceitará o truco
    if(baralhoDoJogador.size() == 3 && soma >= 22)
        return true;
    else if(baralhoDoJogador.size() == 2 && soma >= 14)
        return true;
    else if(baralhoDoJogador.size() == 1 && soma >= 8)
        return true;
    else {  // caso contrário o bot tem 20% de chance de "aceitar o truco no facão"

        // gera um inteiro aleatório no intervalo [1, 10]
        std::mt19937 gen(static_cast<long unsigned int>(time(0)));
        std::uniform_int_distribution<> dis(1, 10);
        int aceitaTruco = dis(gen);

        // 20% de chance da variável aceitaTruco ser 1 ou 2
        if(aceitaTruco <= 2)
            return true;
        else
            return false;
    }
}

// determina se o bot irá pedir truco ou não
bool Bot::pedirTruco(){
    int soma = 0;
    // soma os valores das cartas do bot
    for (unsigned int i = 0; i < baralhoDoJogador.size(); i++)
        soma += baralhoDoJogador[i].getValor();

    // se o bot estiver com uma mão razoavelmente boa ele pedirá truco
    if(baralhoDoJogador.size() == 3 && soma >= 22)
        return true;
    else if(baralhoDoJogador.size() == 2 && soma >= 14)
        return true;
    else if(baralhoDoJogador.size() == 1 && soma >= 8)
        return true;
    else {  // caso contrário o bot tem 30% de chance de "pedir truco no facão"

        // gera um inteiro aleatório no intervalo [1, 10]
        std::mt19937 gen(static_cast<long unsigned int>(time(0)));
        std::uniform_int_distribution<> dis(1, 10);
        int pedeTruco = dis(gen);

        // 30% de chance da variável pedeTruco ser 1, 2 ou 3
        if(pedeTruco <= 3)
            return true;
        else
            return false;
    }
}

}
