#ifndef PESSOA_H_INCLUDED
#define PESSOA_H_INCLUDED

#include <string>
#include "jogador.h"

namespace final{

// definição da classe Pessoa
class Pessoa : public Jogador{
public:
    Pessoa(std::string);  // construtor que recebe o nome da pessoa como parâmetro

    std::string getNome();  // retorna o nome da pessoa

    Carta jogarCarta(unsigned int);  // retorna a carta que está em determinada
    // posição do baralho da pessoa

private:
    std::string _nome;  // nome da pessoa
};

}

#endif // PESSOA_H_INCLUDED
