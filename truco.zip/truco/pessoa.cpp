#include <stdexcept>
#include "pessoa.h"

namespace final{

// construtor que recebe o nome da pessoa como parâmetro
Pessoa::Pessoa(std::string nome){
    this->_nome = nome;
}

// retorna o nome da pessoa
std::string Pessoa::getNome(){
    return _nome;
}

// retorna a carta que está na posição que é passada como parâmetro
Carta Pessoa::jogarCarta(unsigned int posicao){
    if(posicao >= baralhoDoJogador.size())  // verifica se a posição recebida é válida
        throw std::invalid_argument("Posicao invalida");

    Carta carta;
    carta = baralhoDoJogador[posicao];  // salva qual a carta a ser retirada

    // adiciona a última carta na posição da carta a ser retirada
    baralhoDoJogador[posicao] = baralhoDoJogador[baralhoDoJogador.size()-1];

    baralhoDoJogador.pop_back();  // retira a última carta
    return carta;
}

}
