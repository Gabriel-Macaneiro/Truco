#include "jogador.h"

namespace final{

// construtor padrão inicializa os pontos do jogador em zero
Jogador::Jogador(){
    _pontos = 0;
}

// retorna o número de pontos do jogador
int Jogador::getPontos(){
    return _pontos;
}

// retorna o baralho do jogador
std::vector<Carta> Jogador::getBaralhoDoJogador(){
    return baralhoDoJogador;
}

// adiciona uma carta passada como parâmetro no baralho do jogador
void Jogador::receberCarta(Carta novacarta){
    baralhoDoJogador.push_back(novacarta);
}

// remove todas as cartas do baralho do jogador
void Jogador::redefinirCartas(){
    baralhoDoJogador.clear();
}

// aumenta o número de pontos do jogador de acordo com o parâmetro
void Jogador::adicionarPontos(int pontos){
    this->_pontos += pontos;
}

}
