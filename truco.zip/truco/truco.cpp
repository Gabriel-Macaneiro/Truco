#include <iostream>
#include "truco.h"

namespace final{

// construtor inicializa a variável de controle como true
// comecaJogando == true -> pessoa começa jogando
Truco::Truco(){
    this->comecaJogando = true;
}

// inicia uma partida de truco
void Truco::jogar(Pessoa& pessoa, Bot& bot, Baralho& baralho, Mao& mao){
    // loop que persiste até que um dos jogadores ganhe o truco (atinja 12 pontos ou mais)
    while (pessoa.getPontos() < 12 && bot.getPontos() < 12){
        mao.jogar(pessoa, bot, baralho, comecaJogando);  // chama o método jogar do objeto mão
        comecaJogando = !comecaJogando;  // alterna o valor da variável booleana(ora true ora false)
    }
}

// verifica quem ganhou a partida
void Truco::quemGanhou(Pessoa& pessoa, Bot& bot){
    // verifica se foi a pessoa que ganhou o truco e a parabeniza
    if(pessoa.getPontos() >= 12){
        system("cls || clear");
        std::cout << "Parabens! Voce foi o ganhador do truco" << std::endl;
    }

    // verifica se foi o bot que ganhou o truco e informa o usuário
    if(bot.getPontos() >= 12) {
        system("cls || clear");
        std::cout << "Voce perdeu o truco para o Bot" << std::endl;
    }
}

}
