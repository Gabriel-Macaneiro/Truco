#include <iostream>
#include "carta.h"

namespace final{

// construtor inicia os valores inteiros naipe e carta como zero
// e chama as funções que atribuem os chars e o nome das cartas
Carta::Carta(){
    this->_naipe = 0;
    this->_valor = 0;
    setChars();
    setNome();
}

// construtor de cópia que inicializa a carta com todos os
// atributos iguais ao da carta que foi passada como argumento
Carta::Carta(const Carta& outra){
    this->_valor = outra._valor;
    this->_naipe = outra._naipe;
    this->_charValor = outra._charValor;
    this->_charNaipe = outra._charNaipe;
    this->_nome = outra._nome;
}

// construtor que recebe os valores do naipe e da carta como
// parâmetro e chama as funções que atribuem os chars e o nome
// das cartas
Carta::Carta(int naipeDaCarta, int valorDaCarta){
    this->_naipe = naipeDaCarta;
    this->_valor = valorDaCarta;
    setChars();
    setNome();
}

// retorna o valor do naipe da carta
int Carta::getNaipe() const{
    return _naipe;
}

// retorna o valor da carta
int Carta::getValor() const{
    return _valor;
}

// retorna o char que representa o naipe da carta
char Carta::getCharNaipe() const{
    return _charNaipe;
}

// retorna o char que representa a carta
char Carta::getCharValor() const{
    return _charValor;
}

// retorna o nome da carta
std::string Carta::getNome() const{
    return _nome;
}

// permite igualar todos os atributos entre duas cartas
Carta& Carta::operator = (const Carta& carta){
    this->_valor = carta._valor;
    this->_naipe = carta._naipe;
    this->_charValor = carta._charValor;
    this->_charNaipe = carta._charNaipe;
    this->_nome = carta._nome;
    return *this;
}

// atribui o char _naipe  para cada uma das cartas de acordo
// com seus valores
void Carta::setChars(){
    switch(_naipe){
    case 0:
        _charNaipe = 'o';
        break;
    case 1:
        _charNaipe = 'e';
        break;
    case 2:
        _charNaipe = 'c';
        break;
    case 3:
        _charNaipe = 'p';
        break;
    default:
        break;
    }
}

// atribui o nome e o char _valor cada carta de acordo com seus valores
void Carta::setNome(){
    switch(_valor){
    case 0:
        _charValor = '4';
        if (_naipe == 0)
            _nome = "quatro de ouro";
        else if (_naipe == 1)
            _nome = "quatro de espadas";
        else if (_naipe == 2)
            _nome = "quatro de copas";
        else if (_naipe == 3)
            _nome = "quatro de paus";
        break;
    case 1:
        _charValor = '5';
        if (_naipe == 0)
            _nome = "cinco de ouro";
        else if (_naipe == 1)
            _nome = "cinco de espadas";
        else if (_naipe == 2)
            _nome = "cinco de copas";
        else if (_naipe == 3)
            _nome = "cinco de paus";
        break;
    case 2:
        _charValor = '6';
        if (_naipe == 0)
            _nome = "seis de ouro";
        else if (_naipe == 1)
            _nome = "seis de espadas";
        else if (_naipe == 2)
            _nome = "seis de copas";
        else if (_naipe == 3)
            _nome = "seis de paus";
        break;
    case 3:
        _charValor = '7';
        if (_naipe == 0)
            _nome = "sete de ouro";
        else if (_naipe == 1)
            _nome = "sete de espadas";
        else if (_naipe == 2)
            _nome = "sete de copas";
        else if (_naipe == 3)
            _nome = "sete de paus";
        break;
    case 4:
        _charValor = 'Q';
        if (_naipe == 0)
            _nome = "dama de ouro";
        else if (_naipe == 1)
            _nome = "dama de espadas";
        else if (_naipe == 2)
            _nome = "dama de copas";
        else if (_naipe == 3)
            _nome = "dama de paus";
        break;
    case 5:
        _charValor = 'J';
        if (_naipe == 0)
            _nome = "valete de ouro";
        else if (_naipe == 1)
            _nome = "valete de espadas";
        else if (_naipe == 2)
            _nome = "valete de copas";
        else if (_naipe == 3)
            _nome = "valete de paus";
        break;
    case 6:
        _charValor = 'K';
        if (_naipe == 0)
            _nome = "rei de ouro";
        else if (_naipe == 1)
            _nome = "rei de espadas";
        else if (_naipe == 2)
            _nome = "rei de copas";
        else if (_naipe == 3)
            _nome = "rei de paus";
        break;
    case 7:
        _charValor = 'A';
        if (_naipe == 0)
            _nome = "as de ouro";
        else if (_naipe == 1)
            _nome = "as de espadas";
        else if (_naipe == 2)
            _nome = "as de copas";
        else if (_naipe == 3)
            _nome = "as de paus";
        break;
    case 8:
        _charValor = '2';
        if (_naipe == 0)
            _nome = "dois de ouro";
        else if (_naipe == 1)
            _nome = "dois de espadas";
        else if (_naipe == 2)
            _nome = "dois de copas";
        else if (_naipe == 3)
            _nome = "dois de paus";
        break;
    case 9:
        _charValor = '3';
        if (_naipe == 0)
            _nome = "tres de ouro";
        else if (_naipe == 1)
            _nome = "tres de espadas";
        else if (_naipe == 2)
            _nome = "tres de copas";
        else if (_naipe == 3)
            _nome = "tres de paus";
        break;
    default:
        break;
    }
}

// permite imprimir os dados da carta na tela
std::ostream& operator << (std::ostream& out, const Carta& carta){
    out << carta._charValor << carta._charNaipe << "(" << carta._nome << ")";
    return out;
}

}
