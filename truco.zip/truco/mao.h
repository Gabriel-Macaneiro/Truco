#ifndef MAO_H_INCLUDED
#define MAO_H_INCLUDED

#include <vector>
#include "interface.h"
#include "baralho.h"
#include "pessoa.h"
#include "bot.h"

namespace final{

// definição da classe Mao
class Mao{
public:
    Mao();  // construtor padrão da classe Mao

    void jogar(Pessoa&, Bot&, Baralho&, bool);  // método para iniciar uma mão

    // método para embaralhar e distribuir as cartas para os jogadores
    void embaralhaDistribui(Pessoa&, Bot&, Baralho&);

    // método para controlar cada rodada em uma mão
    void controlaRodadas(Pessoa&, Bot&, Carta&, Carta&, Interface&, bool&);

    // método para controlar todos os pedidos de truco dos jogadores
    void controlaTruco(Pessoa&, Bot&, bool);

    // método para reiniciar todas as variáveis para seus valores padrões
    void limpar();

    // método para verificar qual é a carta que vale mais (leva em consideração
    // o vira da mão)
    int comparaCartas(const Carta&, const Carta&);

    // método para verificar quem ganhou a mão
    void comparaQuemGanhou(Pessoa&, Bot&, int&, int&, bool&);

private:
    Carta vira; // carta que determina as quatro manilhas da mão

    int _valorDaMao; // valor da mão

    int _numeroDeRodadasGanhasPessoa;  // número de rodadas que a pessoa ganhou em uma mão

    int _numeroDeRodadasGanhasBot;  // número de rodadas que o bot ganhou em uma mão

    // variável que controla quem foi o último a levantar o valor da mão
    // se _quemLevantouPorUltimo == 1 -> pessoa levantou o valor por último
    // se _quemLevantouPorUltimo == -1 -> bot levantou o valor por último
    // se _quemLevantouPorUltimo == 0 -> valor padrão que inicia toda mão
    int _quemLevantouPorUltimo;

    // variável que controla se alguém desistiu de um pedido de levantar o valor da mão
    // se _desistencia == true -> a pessoa ou o bot desistiu da mão
    bool _desistencia;
};

}

#endif // MAO_H_INCLUDED
