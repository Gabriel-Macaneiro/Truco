#ifndef INTERFACE_H_INCLUDED
#define INTERFACE_H_INCLUDED

#include "carta.h"
#include "pessoa.h"
#include "bot.h"

namespace final{

// definição da classe Interface
class Interface{
public:
    // interface mostra os pontos de cada jogador, as cartas da pessoa
    // e o valor da mão
    void mostraInterface(Pessoa&, Bot&, Carta, int);

    // limpa o terminal
    void limpaInterface();
};

}

#endif // INTERFACE_H_INCLUDED
