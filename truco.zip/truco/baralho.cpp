#include <random>
#include <algorithm>
#include <chrono>
#include "baralho.h"

namespace final{

// construtor que preenche o vetor de cartas com quarenta cartas tal qual um jogo de truco
// inicializa a posição como zero (representando a primeira carta do baralho)
Baralho::Baralho(){
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 4; j++){
            baralho.push_back(Carta(j, i));
        }
    }
    this->_posicao = 0;
}

// rearranja as cartas do baralho aleatoriamente (embaralha)
void Baralho::embaralhar(){
    // gerador de números pseudoaleatórios que é utilizado como fonte de aleatoriedade
    // na função que rearranja as cartas
    std::default_random_engine engine(static_cast <long unsigned int> (time(0)));

    std::shuffle(baralho.begin(), baralho.end(), engine);

    // sempre que o baralho é embaralhado a posição passa a representar a primeira carta novamente
    this->_posicao = 0;
}

// retorna a carta que está em determinada posição e após o retorno incrementa a posição
Carta Baralho::pescar(){
    return baralho[_posicao++];
}

}
