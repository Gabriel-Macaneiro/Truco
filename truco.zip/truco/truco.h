#ifndef TRUCO_H_INCLUDED
#define TRUCO_H_INCLUDED

#include "mao.h"

namespace final{

// definição da classe Truco
class Truco{
public:
    Truco();  // construtor padrão da classe Truco

    void jogar(Pessoa&, Bot&, Baralho&, Mao&);  // método para iniciar uma partida de truco

    void quemGanhou(Pessoa&, Bot&);  // método para verificar quem ganhou a partida

private:
    // variável de controle para alternar quem começa jogando cada mão
    // se comecaJogando == true -> pessoa começa jogando
    // se comecaJogando == false -> bot começa jogando
    bool comecaJogando;
};

}

#endif // TRUCO_H_INCLUDED
