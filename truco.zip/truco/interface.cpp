#include <iostream>
#include "interface.h"

namespace final{

// mostra os pontos de cada jogador, o valor da mão e as cartas da pessoa
void Interface::mostraInterface(Pessoa& pessoa, Bot& bot, Carta vira, int valorDaMao){
    std::vector<Carta> vetorDemonstrativo = pessoa.getBaralhoDoJogador();
    this->limpaInterface();

    // mostra quantos pontos cada jogador tem
    std::cout << "Pontos" << std::endl;
    std::cout << pessoa.getNome() << ": " << pessoa.getPontos() << std::endl;
    std::cout << bot.getNome() << ": " << bot.getPontos() << "\n\n";

    // mostra o valor atual da mão
    std::cout << "Valor Atual da Mao: ";
    if(valorDaMao == 1)
        std::cout << valorDaMao << " ponto\n\n";
    else
        std::cout << valorDaMao << " pontos\n\n";

    // mostra em qual rodada da mão o jogo está
    if(vetorDemonstrativo.size() == 3)
        std::cout << "\t\t\tRodada 1" << std::endl;
    else if(vetorDemonstrativo.size() == 2)
        std::cout << "\t\t\tRodada 2" << std::endl;
    else if(vetorDemonstrativo.size() == 1)
        std::cout << "\t\t\tRodada 3" << std::endl;

    // mostra as cartas da pessoa e oculta com Xx as cartas do bot
    std::cout << "\n    Suas cartas " << "\t\t\t" << " Cartas do Bot" << std::endl;
    for (unsigned int i = 0; i < vetorDemonstrativo.size(); i++)
        std::cout << "\t" << vetorDemonstrativo[i].getCharValor() << vetorDemonstrativo[i].getCharNaipe()
        << "\t\t\t\t       " << "Xx" << std::endl;

    // mostra o vira
    std::cout << "\n" << "\t\t Vira: " << vira;

    // mostra o nome das cartas da pessoa
    std::cout << "\n\nSuas Cartas\n";
    for (unsigned int i = 0; i < vetorDemonstrativo.size(); i++)
        std::cout << i+1 << ": " << vetorDemonstrativo[i].getNome() << std::endl;
}

// limpa o terminal
void Interface::limpaInterface(){
    system("cls || clear");
}

}
