#ifndef CARTA_H_INCLUDED
#define CARTA_H_INCLUDED

#include <string>

namespace final{

/*TABELA DE VALORES DAS CARTAS E DOS NAIPES
carta '4' -> valor 0          naipe 'o'(ouro)    -> valor 0
carta '5' -> valor 1          naipe 'e'(espadas) -> valor 1
carta '6' -> valor 2          naipe 'c'(copas)   -> valor 2
carta '7' -> valor 3          naipe 'p'(paus)    -> valor 3
carta 'Q' -> valor 4
carta 'J' -> valor 5
carta 'K' -> valor 6
carta 'A' -> valor 7
carta '2' -> valor 8
carta '3' -> valor 9
*/

// definição da classe Carta
class Carta{
public:
    Carta();  // construtor padrão da classe Carta

    Carta(const Carta&);  // construtor de cópia da classe Carta

    Carta(int, int);  // construtor com parâmetros inteiros(valores) da classe Carta

    int getNaipe() const;  // método que retorna o valor do naipe da carta

    int getValor() const;  // método que retorna o valor da própria carta

    char getCharNaipe() const;  // método que retorna o char que representa o naipe da carta

    char getCharValor() const;  // método que retorna o char que representa a carta

    std::string getNome() const;  // método que retorna o nome da carta

    Carta& operator = (const Carta&);  // sobrecarga do operador = que permite igualar duas cartas

    // sobrecarga do operador << que permite imprimir uma carta na tela
    friend std::ostream& operator << (std::ostream&, const Carta&);

private:
    //Atributos
    int _naipe;  // inteiro que representa o valor do naipe da carta

    int _valor;  // inteiro que representa o valor da própria carta

    char _charNaipe;  // char que representa o naipe da carta

    char _charValor;  // char que representa a carta

    std::string _nome;  // nome da carta

    //M�todos
    void setChars();  // método para atribuir os chars das cartas a partir dos seus valores

    void setNome();  // método para atribuir o nome das cartas a partir dos seus valores
};

}

#endif // CARTA_H_INCLUDED
