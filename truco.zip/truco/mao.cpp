#include <iostream>
#include "mao.h"

namespace final{


// construtor para inicializar os atributos com seus valores padrões para o início da mão
Mao::Mao(){
    this->_valorDaMao = 1;
    this->_numeroDeRodadasGanhasBot = 0;
    this->_numeroDeRodadasGanhasPessoa = 0;
    this->_quemLevantouPorUltimo = 0;
    this->_desistencia = false;
}


void Mao::jogar(Pessoa& pessoa, Bot& bot, Baralho& baralho, bool comecaJogando){
    Interface interface;  // cria um objeto interface para mostrar as rodadas ao usuário
    Carta cartaPessoa;  // recebe a carta que a pessoa retirar do seu baralho(carta que ela joga)
    Carta cartaBot;  // recebe a carta que o bot retirar do seu baralho(carta que ele joga)
    int comparacao;  // recebe o retorno da função comparaCartas para enviar para a função comparaQuemGanhou

    int primeira = 0;  // representa quem ganhou a primeira rodada (caso tenha empates nas próximas rodadas,
    // ganha a mão quem ganhou a primeira rodada)
    // se primeira == 1 -> pessoa ganhou a primeira rodada
    // se primeira == -1 -> bot ganhou a primeira rodada
    // se primeira == 0 -> ou não ocorreu a primeira rodada ainda, ou ela empatou

    bool quemJoga = (comecaJogando) ? true : false; // representa de quem é a vez de jogar
    // se quemJoga == true -> vez da pessoa jogar
    // se quemJoga == false -> vez do bot jogar

    this->limpar();  // reinicia o valor de todos os atributos para os seus padrões
    this->embaralhaDistribui(pessoa, bot, baralho);  // embaralha e distribui as cartas para os jogadores

    // loop que persiste até que a pessoa ou o bot ganhe a mão
    while(_numeroDeRodadasGanhasPessoa != 2 && _numeroDeRodadasGanhasBot != 2){
        // mostra os pontos de cada jogador, o valor da mão e as cartas da pessoa
        interface.mostraInterface(pessoa, bot, this->vira, _valorDaMao);

        // controla cada rodada em uma mão
        controlaRodadas(pessoa, bot, cartaPessoa, cartaBot, interface, quemJoga);

        // se algum jogador desistiu do truco, a mão termina sem precisar comparar cartas nem quem ganhou
        if(this->_desistencia == true)
            return;

        // recebe resultado de qual das cartas é maior
        comparacao = comparaCartas(cartaPessoa, cartaBot);

        // verifica quem ganhou a rodada (ou se houve um empate)
        comparaQuemGanhou(pessoa, bot, comparacao, primeira, quemJoga);
    }
}


// verifica qual das duas cartas recebidas vale mais e leva em consideração o vira da mão
// se comparaCartas retorna int positivo -> carta1 vale mais que carta2
// se comparaCartas retorna int negativo -> carta2 vale mais que carta1
// se comparaCartas retorna zero -> as duas cartas têm o mesmo valor
int Mao::comparaCartas(const Carta& carta1, const Carta& carta2){
    // verifica se o vira é a carta 3, pois nesse caso específico as manilhas
    // são as cartas 4 (o valor da carta 3 é 9 e o valor da carta 4 é 0)
    if(this->vira.getValor() == 9){
        if((carta1.getValor() == 0) && (carta2.getValor() == 0))
            return carta1.getNaipe() - carta2.getNaipe();
        else if(carta1.getValor() == 0)
            return 1;
        else if(carta2.getValor() == 0)
            return -1;
        else
            return carta1.getValor() - carta2.getValor();
    }

    // se o vira não for 3, as manilhas possuem sempre o valor do vira + 1
    if((carta1.getValor() == this->vira.getValor()+1) && (carta2.getValor() == this->vira.getValor()+1))
        return carta1.getNaipe() - carta2.getNaipe();
    else if(carta1.getValor() == this->vira.getValor()+1)
        return 1;
    else if(carta2.getValor() == this->vira.getValor()+1)
        return -1;
    else
        return carta1.getValor() - carta2.getValor();
}


// verifica quem ganhou a mão
void Mao::comparaQuemGanhou(Pessoa& pessoa, Bot& bot, int& comparacao, int& primeira, bool& quemJoga){
    // verifica se houve um empate, e, através do tamanho do baralho dos jogadores, em qual rodada esse
    // empate ocorreu para dar a vitória da mão ao jogador certo
    if(comparacao == 0){
            if(pessoa.baralhoDoJogador.size() == 2){
                _numeroDeRodadasGanhasBot++;
                _numeroDeRodadasGanhasPessoa++;
            } else if(pessoa.baralhoDoJogador.size() == 1){
                if(primeira == 1)
                    _numeroDeRodadasGanhasPessoa++;
                else if(primeira == -1)
                    _numeroDeRodadasGanhasBot++;
            } else if(pessoa.baralhoDoJogador.size() == 0){
                if(primeira == 1)
                    _numeroDeRodadasGanhasPessoa++;
                else if(primeira == -1)
                    _numeroDeRodadasGanhasBot++;
                else{  // caso as três rodadas da mão tenham empatado
                    std::cout << "\nEsta mao empatou!" << std::endl;
                    //system("PAUSE");
                    system("sleep 5");
                }
            }
        } else if(comparacao > 0){  // verifica se a pessoa ganhou a rodada
            _numeroDeRodadasGanhasPessoa++;
            quemJoga = true;  // a pessoa ganhou a rodada, logo, será a próxima a jogar
            if(pessoa.baralhoDoJogador.size() == 2)
                primeira = 1;
        } else {  // caso contrário, o bot ganhou a rodada
            _numeroDeRodadasGanhasBot++;
            quemJoga = false;  // o bot ganhou a rodada, logo, será o próximo a jogar
            if(pessoa.baralhoDoJogador.size() == 2)
                primeira = -1;
        }

    // verifica se a pessoa ganhou a mão e adiciona os pontos para ela
    if(_numeroDeRodadasGanhasPessoa == 2){
        std::cout << "\nVoce ganhou esta mao!" << std::endl;
        pessoa.adicionarPontos(_valorDaMao);
        //system("PAUSE");
        system("sleep 5");
    }

    // verifica se o bot ganhou a mão e adiciona os pontos para ele
    if(_numeroDeRodadasGanhasBot == 2){
        std::cout << "\nO Bot ganhou esta mao!" << std::endl;
        bot.adicionarPontos(_valorDaMao);
        //system("PAUSE");
        system("sleep 5");
    }
}


// controla cada rodada de uma mão
void Mao::controlaRodadas(Pessoa& pessoa, Bot &bot, Carta& cartaPessoa, Carta& cartaBot, Interface& interface, bool& quemJoga){
    unsigned int posicao;  // representa a posição que o jogador escolher retirar uma carta de seu baralho (jogar a carta)

    bool jaJogou = true;  // variável de controle que se mantém em true até que o jogador jogue uma carta
    // serve para auxiliar no controle dos pedidos de truco

    if (quemJoga == true){  // se for a vez da pessoa jogar
        while(jaJogou){  // loop que persiste até que o jogador jogue uma carta
            do {  // loop que persiste até que o jogador selecione uma posição válida
                std::cout << "\nEscolha uma carta para jogar(0 para levantar o valor da mao): ";
                std::cin >> posicao;
                if (posicao > pessoa.baralhoDoJogador.size())  // verifica se a posição é válida
                    std::cout << "Posicao invalida!" << std::endl;
            } while (posicao > pessoa.baralhoDoJogador.size());

            if(posicao == 0){  // verifica se a pessoa pediu para levantar o valor da mao
                this->controlaTruco(pessoa, bot, true);
                if(this->_desistencia == true)  // verifica se o bot desistiu do pedido
                    return;
                interface.mostraInterface(pessoa, bot, this->vira, _valorDaMao);
            } else {  // caso a pessoa tenha escolhido uma posição que possui uma carta
                cartaPessoa = pessoa.jogarCarta(posicao-1);
                jaJogou = false;  // para sair do loop

                if(bot.pedirTruco()){  // verifica se o bot quer levantar o valor da mão
                    this->controlaTruco(pessoa, bot, false);
                    if(this->_desistencia == true)  // verifica se a pessoa desistiu do pedido
                        return;
                    interface.mostraInterface(pessoa, bot, this->vira, _valorDaMao);
                }

                cartaBot = bot.jogarCarta(cartaPessoa);
                std::cout << "\nVoce jogou: " << cartaPessoa << std::endl;
                std::cout << "O bot jogou: " << cartaBot << std::endl;
                //system("PAUSE");
                system("sleep 5");
            }
        }
    }

    if (quemJoga == false){  // se for a vez do bot jogar
        if(bot.pedirTruco()){  // verifica se o bot quer levantar o valor da mão
            this->controlaTruco(pessoa, bot, false);
            if(this->_desistencia == true)  // verifica se a pessoa desistiu do pedido
                return;
            interface.mostraInterface(pessoa, bot, this->vira, _valorDaMao);
        }

        cartaBot = bot.jogarCarta();
        while(jaJogou){  // loop que persiste até que o jogador jogue uma carta
            std::cout << "\nO bot jogou: " << cartaBot << std::endl;
            do {  // loop que persiste até que o jogador selecione uma posição válida
                std::cout << "\nEscolha uma carta para jogar(0 para levantar o valor da mao): ";
                std::cin >> posicao;
                if (posicao > pessoa.baralhoDoJogador.size())
                    std::cout << "Posicao invalida!" << std::endl;
            } while (posicao > pessoa.baralhoDoJogador.size());

            if(posicao == 0){  // verifica se a pessoa pediu para levantar o valor da mão
                this->controlaTruco(pessoa, bot, true);
                if(this->_desistencia == true)  // verifica se o bot desistiu do pedido
                    return;
                interface.mostraInterface(pessoa, bot, this->vira, _valorDaMao);
            } else {  // caso a pessoa tenha escolhido uma posição que possui uma carta
                cartaPessoa = pessoa.jogarCarta(posicao-1);
                jaJogou = false;  // para sair do loop
            }
        }
    }
}


// controla os pedidos de levantamento do valor da mão
void Mao::controlaTruco(Pessoa& pessoa, Bot& bot, bool quemPediu){
    // verifica a pessoa pediu para levantar o valor da mão e se ela foi a última a pedir
    if(quemPediu == true && this->_quemLevantouPorUltimo == 1){
        std::cout << "Voce ja foi o ultimo a levantar o valor da mao" << std::endl;
        system("sleep 3");
        //system("PAUSE");
        return;
    }

    // verifica se o bot pediu para levantar o valor da mão e se ele foi o último a pedir
    if(quemPediu == false && this->_quemLevantouPorUltimo == -1)
        return;

    // verifica se a pessoa pediu para levantar o valor da mão e se o valor da mão já está no máximo
    if(quemPediu == true && _valorDaMao == 12){
        std::cout << "Valor da rodada ja esta no maximo" << std::endl;
        //system("PAUSE");
        system("sleep 3");
        return;
    }

    // verifica se o bot pediu para levantar o valor da mão e se o valor da mão já está no máximo
    if(quemPediu == false && _valorDaMao == 12){
        return;
    }

    char resposta;  // char que armazena se o pedido foi aceitou ou não
    if(quemPediu == true){  // verifica se quem pediu foi a pessoa
        if(bot.aceitarTruco()){  // verifica se o bot aceita o pedido
            std::cout << "O Bot aceitou" << std::endl;
            //system("PAUSE");
            system("sleep 3");
            resposta = 's';
        } else {
            std::cout << "O Bot recusou" << std::endl;
            //system("PAUSE");
            system("sleep 3");
            resposta = 'n';
        }
    } else {  // caso contrário, o bot foi quem pediu para levantar o valor da mão
        std::cout << "\nO bot levantou o valor da mao" << std::endl;
        do {  // loop que permanece até a pessoa responder 's' ou 'n'
            std::cout << "Se voce aceita digite 's', para desistir digite 'n': ";
            std::cin >> resposta;
            if(resposta != 'n' && resposta != 's')  // verifica se a resposta é válida
                std::cout << "Reposta invalida" << std::endl;
        } while (resposta != 'n' && resposta != 's');
    }

    if (resposta == 'n'){  // verifica se a resposta foi 'n' -> não
        // se a pessoa pediu para levantar o valor e o bot desistiu, a pessoa ganha os pontos
        if(quemPediu == true){
            pessoa.adicionarPontos(_valorDaMao);
            this->_desistencia = true;
        } else {  // caso contrário, o bot foi quem fez o pedido, ele ganha os pontos
            bot.adicionarPontos(_valorDaMao);
            this->_desistencia = true;
        }
    }

    // verifica se a resposta foi 's' -> sim
    // aumenta o valor da mão de acordo com seu valor atual
    if (resposta == 's'){
        switch(_valorDaMao){
        case 1:
            _valorDaMao = 3;
            break;
        case 3:
            _valorDaMao = 6;
            break;
        case 6:
            _valorDaMao = 9;
            break;
        case 9:
            _valorDaMao = 12;
            break;
        default:
            break;
        }
        if(quemPediu == true)  // se foi a pessoa que pediu para levantar o valor
            _quemLevantouPorUltimo = 1;  // representa que ela foi a última a pedir
        else
            _quemLevantouPorUltimo = -1;  // representa que o bot foi o último a pedir
    }
}


// embaralha e distribui as cartas para os jogadores
void Mao::embaralhaDistribui(Pessoa& pessoa, Bot& bot, Baralho& baralho){
    baralho.embaralhar();
    pessoa.redefinirCartas();  // remove as cartas do baralho da pessoa
    bot.redefinirCartas();  // remove as cartas do baralho do bot

    // pesca alternadamente cartas para a pessoa e o bot
    for(int i = 0; i < 3; i++){
        pessoa.receberCarta(baralho.pescar());
        bot.receberCarta(baralho.pescar());
    }

    // pesca o vira da mão
    this->vira = baralho.pescar();
}


// reinicia o valor de todos os atributos para os seus padrões
void Mao::limpar(){
    _quemLevantouPorUltimo = 0;
    _numeroDeRodadasGanhasBot = 0;
    _numeroDeRodadasGanhasPessoa = 0;
    _valorDaMao = 1;
    _desistencia = false;
}

}
