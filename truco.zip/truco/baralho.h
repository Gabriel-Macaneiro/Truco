#ifndef BARALHO_H_INCLUDED
#define BARALHO_H_INCLUDED

#include <vector>
#include "carta.h"

namespace final{

// definição da classe Baralho
class Baralho{
public:
    Baralho();  // construtor padrão da classe Baralho

    void embaralhar();  // método que embaralha o vetor de cartas da classe Baralho

    Carta pescar();  // método que retorna a carta que está em determinada posição

private:
    std::vector<Carta> baralho;  // vetor de cartas que representa um baralho de truco

    long unsigned int _posicao;  // inteiro que percorre as posições do vetor de cartas
    // para impedir que seja retornada uma determinada carta mais de uma vez
};

}

#endif // BARALHO_H_INCLUDED
