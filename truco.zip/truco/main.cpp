// Trabalho final de programação 3
// Demonstração de um jogo de truco
#include <iostream>
#include "truco.h"

int main(){
    std::string nome;  // vetor de caracteres para armazenar o nome do usuário
    std::cout << "Bem vindo ao Truco!" << std::endl;

    // lê o nome do usuário
    std::cout << "Digite seu nome: ";
    std::getline(std::cin, nome);

    final::Pessoa pessoa(nome);  // cria um objeto pessoa com o nome recebido pelo usuário
    final::Baralho baralho;  // cria um baralho com 40 cartas, típico para o jogo de truco
    final::Mao mao;  // cria o objeto mão que comanda cada mão do truco
    final::Bot bot;  // cria um bot que será o adversário da pessoa no truco
    final::Truco truco;  // cria uma partida de truco

    truco.jogar(pessoa, bot, baralho, mao);  // começa a partida de truco

    truco.quemGanhou(pessoa, bot);  // verifica quem ganhou a partida

    return 0;
}
